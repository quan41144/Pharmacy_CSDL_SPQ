create function fn_prevent_modify_completed_slips() returns trigger
    language plpgsql
as
$$
BEGIN
    IF TG_OP = 'DELETE' THEN
        IF OLD.status NOT IN ('PENDING', 'UNPAID') THEN
            RAISE EXCEPTION 'Chứng từ đã hoàn tất hoặc đã hủy, không được xóa.';
        END IF;
        RETURN OLD;
    ELSIF TG_OP = 'UPDATE' THEN
        IF OLD.status IN ('IMPORTED', 'PAID', 'DISPOSED', 'CANCELLED') THEN
            RAISE EXCEPTION 'Chứng từ đã hoàn tất hoặc đã hủy, không được phép chỉnh sửa.';
        END IF;
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$;

alter function fn_prevent_modify_completed_slips() owner to postgres;

