create function fn_calc_invoice_item() returns trigger
    language plpgsql
as
$$
DECLARE
    v_status VARCHAR(30);
    v_warehouse_id BIGINT;
    v_exp_date DATE;
    v_stock INT;
    v_selling_price NUMERIC(15,2);
BEGIN
    SELECT status, warehouse_id INTO v_status, v_warehouse_id
    FROM invoices
    WHERE invoice_id = COALESCE(NEW.invoice_id, OLD.invoice_id);

    IF v_status <> 'UNPAID' THEN
        RAISE EXCEPTION 'Chỉ được thêm/sửa chi tiết khi hóa đơn ở trạng thái UNPAID.';
    END IF;

    IF TG_OP IN ('INSERT', 'UPDATE') THEN
        SELECT b.exp_date, p.selling_price, COALESCE(i.quantity, 0)
        INTO v_exp_date, v_selling_price, v_stock
        FROM batches b
        JOIN products p ON p.product_id = b.product_id
        LEFT JOIN inventories i ON i.batch_id = b.batch_id AND i.warehouse_id = v_warehouse_id
        WHERE b.batch_id = NEW.batch_id;

        IF v_exp_date <= CURRENT_DATE THEN
            RAISE EXCEPTION 'Lô thuốc % đã hết hạn sử dụng (%)', NEW.batch_id, v_exp_date;
        END IF;

        IF v_stock < NEW.quantity THEN
            RAISE EXCEPTION 'Số lượng tồn kho không đủ cho lô % (Tồn: %, Cần bán: %)', NEW.batch_id, v_stock, NEW.quantity;
        END IF;

        IF TG_OP = 'INSERT' AND (NEW.unit_price IS NULL OR NEW.unit_price = 0) THEN
            NEW.unit_price := v_selling_price;
        END IF;

        NEW.sub_total := NEW.quantity * NEW.unit_price;
        RETURN NEW;
    END IF;
    RETURN OLD;
END;
$$;

alter function fn_calc_invoice_item() owner to postgres;

