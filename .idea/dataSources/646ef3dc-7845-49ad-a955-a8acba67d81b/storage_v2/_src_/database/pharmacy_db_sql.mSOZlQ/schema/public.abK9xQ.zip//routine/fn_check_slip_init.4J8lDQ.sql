create function fn_check_slip_init() returns trigger
    language plpgsql
as
$$
DECLARE
    v_staff_status VARCHAR(30);
    v_warehouse_status VARCHAR(30);
BEGIN
    SELECT work_status INTO v_staff_status FROM employees WHERE employee_id = NEW.warehouse_staff_id;
    IF v_staff_status IS DISTINCT FROM 'ACTIVE' THEN
        RAISE EXCEPTION 'Nhan vien da ngung lam viec, khong duoc lap chung tu moi.';
    END IF;

    SELECT status INTO v_warehouse_status FROM warehouses WHERE warehouse_id = NEW.warehouse_id;
    IF v_warehouse_status IS DISTINCT FROM 'ACTIVE' THEN
        RAISE EXCEPTION 'Kho da ngung hoat dong, khong duoc chon cho chung tu moi.';
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_check_slip_init() owner to postgres;

