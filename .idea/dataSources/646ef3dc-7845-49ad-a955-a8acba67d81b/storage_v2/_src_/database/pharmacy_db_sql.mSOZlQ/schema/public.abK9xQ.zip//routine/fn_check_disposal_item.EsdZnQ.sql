create function fn_check_disposal_item() returns trigger
    language plpgsql
as
$$
DECLARE
    v_status VARCHAR(30);
    v_warehouse_id BIGINT;
    v_stock INT;
BEGIN
    SELECT status, warehouse_id INTO v_status, v_warehouse_id
    FROM disposal_slips
    WHERE disposal_slip_id = COALESCE(NEW.disposal_slip_id, OLD.disposal_slip_id);

    IF v_status <> 'PENDING' THEN
        RAISE EXCEPTION 'Chỉ được thêm/sửa chi tiết khi phiếu hủy ở trạng thái PENDING.';
    END IF;

    IF TG_OP IN ('INSERT', 'UPDATE') THEN
        SELECT COALESCE(quantity, 0) INTO v_stock
        FROM inventories
        WHERE warehouse_id = v_warehouse_id AND batch_id = NEW.batch_id;

        IF v_stock < NEW.quantity THEN
            RAISE EXCEPTION 'Số lượng hủy vượt quá tồn kho của lô % (Tồn: %, Hủy: %).', NEW.batch_id, v_stock, NEW.quantity;
        END IF;
        RETURN NEW;
    END IF;
    RETURN OLD;
END;
$$;

alter function fn_check_disposal_item() owner to postgres;

