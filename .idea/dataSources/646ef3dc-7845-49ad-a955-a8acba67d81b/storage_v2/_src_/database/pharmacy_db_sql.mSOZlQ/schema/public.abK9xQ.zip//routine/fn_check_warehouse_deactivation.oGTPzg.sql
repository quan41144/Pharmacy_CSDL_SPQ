create function fn_check_warehouse_deactivation() returns trigger
    language plpgsql
as
$$
BEGIN
    IF OLD.status = 'ACTIVE' AND NEW.status = 'INACTIVE' THEN
        IF EXISTS (SELECT 1 FROM inventories WHERE warehouse_id = NEW.warehouse_id AND quantity > 0) THEN
            RAISE EXCEPTION 'Không thể ngừng hoạt động kho khi vẫn còn hàng tồn.';
        END IF;

        IF EXISTS (SELECT 1 FROM import_slips WHERE warehouse_id = NEW.warehouse_id AND status = 'PENDING')
           OR EXISTS (SELECT 1 FROM invoices WHERE warehouse_id = NEW.warehouse_id AND status = 'UNPAID')
           OR EXISTS (SELECT 1 FROM disposal_slips WHERE warehouse_id = NEW.warehouse_id AND status = 'PENDING') THEN
            RAISE EXCEPTION 'Không thể ngừng hoạt động kho khi vẫn còn chứng từ đang chờ xử lý.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

alter function fn_check_warehouse_deactivation() owner to postgres;

