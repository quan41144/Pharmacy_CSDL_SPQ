create function fn_update_import_total() returns trigger
    language plpgsql
as
$$
DECLARE
    v_slip_id BIGINT := COALESCE(NEW.import_slip_id, OLD.import_slip_id);
BEGIN
    UPDATE import_slips
    SET total_amount = COALESCE((SELECT SUM(sub_total) FROM import_slip_items WHERE import_slip_id = v_slip_id), 0.00)
    WHERE import_slip_id = v_slip_id;
    RETURN NULL;
END;
$$;

alter function fn_update_import_total() owner to postgres;

