create function fn_check_active_staff_and_warehouse() returns trigger
    language plpgsql
as
$$
DECLARE
    v_staff_status VARCHAR(30);
    v_warehouse_status VARCHAR(30);
    v_staff_id BIGINT;
BEGIN
    v_staff_id := CASE
        WHEN TG_TABLE_NAME = 'invoices' THEN NEW.sales_staff_id
        ELSE NEW.warehouse_staff_id
    END;

    SELECT work_status INTO v_staff_status FROM employees WHERE employee_id = v_staff_id;
    IF v_staff_status IS DISTINCT FROM 'ACTIVE' THEN
        RAISE EXCEPTION 'Nhân viên đã ngừng làm việc, không được lập chứng từ mới.';
    END IF;

    SELECT status INTO v_warehouse_status FROM warehouses WHERE warehouse_id = NEW.warehouse_id;
    IF v_warehouse_status IS DISTINCT FROM 'ACTIVE' THEN
        RAISE EXCEPTION 'Kho đã ngừng hoạt động, không được chọn cho chứng từ mới.';
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_check_active_staff_and_warehouse() owner to postgres;

