create function fn_calc_import_item() returns trigger
    language plpgsql
as
$$
DECLARE
    v_status VARCHAR(30);
BEGIN
    SELECT status INTO v_status FROM import_slips WHERE import_slip_id = COALESCE(NEW.import_slip_id, OLD.import_slip_id);
    IF v_status <> 'PENDING' THEN
        RAISE EXCEPTION 'Chỉ được thêm/sửa chi tiết khi phiếu nhập ở trạng thái PENDING.';
    END IF;

    IF TG_OP IN ('INSERT', 'UPDATE') THEN
        NEW.sub_total := NEW.quantity * NEW.unit_price;
        RETURN NEW;
    END IF;
    RETURN OLD;
END;
$$;

alter function fn_calc_import_item() owner to postgres;

