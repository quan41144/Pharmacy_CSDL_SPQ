create function fn_update_invoice_total() returns trigger
    language plpgsql
as
$$
DECLARE
    v_inv_id BIGINT := COALESCE(NEW.invoice_id, OLD.invoice_id);
BEGIN
    UPDATE invoices
    SET total_amount = COALESCE((SELECT SUM(sub_total) FROM invoice_items WHERE invoice_id = v_inv_id), 0.00)
    WHERE invoice_id = v_inv_id;
    RETURN NULL;
END;
$$;

alter function fn_update_invoice_total() owner to postgres;

