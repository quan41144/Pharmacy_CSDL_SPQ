create procedure sp_confirm_import_slip(IN p_import_slip_id bigint)
    language plpgsql
as
$$
DECLARE
    v_warehouse_id BIGINT;
    v_status VARCHAR(30);
    v_total NUMERIC(15,2);
    v_item_count INT;
    v_admin_balance NUMERIC(15,2);
    v_admin_id BIGINT;
BEGIN
    SELECT warehouse_id, status, total_amount INTO v_warehouse_id, v_status, v_total
    FROM import_slips
    WHERE import_slip_id = p_import_slip_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Không tìm thấy phiếu nhập %.', p_import_slip_id;
    END IF;

    IF v_status <> 'PENDING' THEN
        RAISE EXCEPTION 'Phiếu nhập không ở trạng thái chờ duyệt (PENDING).';
    END IF;

    SELECT COUNT(*) INTO v_item_count FROM import_slip_items WHERE import_slip_id = p_import_slip_id;
    IF v_item_count = 0 THEN
        RAISE EXCEPTION 'Phiếu nhập phải có ít nhất một dòng chi tiết hợp lệ.';
    END IF;

    -- Khóa và kiểm tra số dư Admin
    SELECT employee_id, balance INTO v_admin_id, v_admin_balance
    FROM employees
    WHERE position = 'ROLE_ADMIN' AND work_status = 'ACTIVE'
    ORDER BY employee_id ASC
    LIMIT 1
    FOR UPDATE;

    IF v_admin_balance IS NULL OR v_admin_balance < v_total THEN
        RAISE EXCEPTION 'Số dư chủ cửa hàng không đủ';
    END IF;

    -- Trừ số dư Admin
    UPDATE employees
    SET balance = balance - v_total
    WHERE employee_id = v_admin_id;

    -- Cộng tồn kho
    INSERT INTO inventories(warehouse_id, batch_id, quantity, updated_at)
    SELECT v_warehouse_id, batch_id, quantity, CURRENT_TIMESTAMP
    FROM import_slip_items
    WHERE import_slip_id = p_import_slip_id
    ON CONFLICT (warehouse_id, batch_id)
    DO UPDATE SET
        quantity = inventories.quantity + EXCLUDED.quantity,
        updated_at = CURRENT_TIMESTAMP;

    -- Chuyển trạng thái sang IMPORTED
    UPDATE import_slips
    SET status = 'IMPORTED'
    WHERE import_slip_id = p_import_slip_id;
END;
$$;

alter procedure sp_confirm_import_slip(bigint) owner to postgres;

