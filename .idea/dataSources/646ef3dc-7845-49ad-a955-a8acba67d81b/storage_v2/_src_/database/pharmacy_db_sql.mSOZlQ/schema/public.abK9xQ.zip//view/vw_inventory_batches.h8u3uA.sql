create view vw_inventory_batches
            (warehouse_id, warehouse_name, batch_id, batch_code, mfg_date, exp_date, days_remaining, expiry_status,
             quantity, product_id, product_name, unit, selling_price, category_name)
as
SELECT i.warehouse_id,
       w.warehouse_name,
       b.batch_id,
       b.batch_code,
       b.mfg_date,
       b.exp_date,
       b.exp_date - CURRENT_DATE AS days_remaining,
       CASE
           WHEN b.exp_date <= CURRENT_DATE THEN 'EXPIRED'::text
           WHEN b.exp_date <= (CURRENT_DATE + '30 days'::interval) THEN 'NEAR_EXPIRY'::text
           ELSE 'VALID'::text
           END                   AS expiry_status,
       i.quantity,
       p.product_id,
       p.product_name,
       p.unit,
       p.selling_price,
       c.category_name
FROM inventories i
         JOIN warehouses w ON w.warehouse_id = i.warehouse_id
         JOIN batches b ON b.batch_id = i.batch_id
         JOIN products p ON p.product_id = b.product_id
         JOIN categories c ON c.category_id = p.category_id;

alter table vw_inventory_batches
    owner to postgres;

