create procedure sp_confirm_disposal_slip(IN p_disposal_slip_id bigint)
    language plpgsql
as
$$
DECLARE
    v_warehouse_id BIGINT;
    v_status VARCHAR(30);
    v_item_count INT;
    v_cur_stock INT;
    r RECORD;
BEGIN
    SELECT warehouse_id, status INTO v_warehouse_id, v_status
    FROM disposal_slips
    WHERE disposal_slip_id = p_disposal_slip_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Không tìm thấy phiếu hủy %.', p_disposal_slip_id;
    END IF;

    IF v_status <> 'PENDING' THEN
        RAISE EXCEPTION 'Phiếu hủy không ở trạng thái chờ hủy (PENDING).';
    END IF;

    SELECT COUNT(*) INTO v_item_count FROM disposal_slip_items WHERE disposal_slip_id = p_disposal_slip_id;
    IF v_item_count = 0 THEN
        RAISE EXCEPTION 'Phiếu hủy phải có ít nhất một dòng chi tiết.';
    END IF;

    -- Kiểm tra lại tồn kho của tất cả các dòng trước khi trừ
    FOR r IN
        SELECT dsi.batch_id, dsi.quantity AS req_qty
        FROM disposal_slip_items dsi
        WHERE dsi.disposal_slip_id = p_disposal_slip_id
    LOOP
        SELECT quantity INTO v_cur_stock
        FROM inventories
        WHERE warehouse_id = v_warehouse_id AND batch_id = r.batch_id
        FOR UPDATE;

        IF NOT FOUND OR v_cur_stock < r.req_qty THEN
            RAISE EXCEPTION 'Từ chối xác nhận hủy: Lô % không đủ tồn kho (Tồn: %, Cần hủy: %).', r.batch_id, COALESCE(v_cur_stock, 0), r.req_qty;
        END IF;

        UPDATE inventories
        SET quantity = quantity - r.req_qty,
            updated_at = CURRENT_TIMESTAMP
        WHERE warehouse_id = v_warehouse_id AND batch_id = r.batch_id;
    END LOOP;

    UPDATE disposal_slips
    SET status = 'DISPOSED',
        disposal_date = CURRENT_TIMESTAMP
    WHERE disposal_slip_id = p_disposal_slip_id;
END;
$$;

alter procedure sp_confirm_disposal_slip(bigint) owner to postgres;

