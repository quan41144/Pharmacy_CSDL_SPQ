create view vw_customers_with_age (customer_id, full_name, date_of_birth, gender, phone, address, note, age) as
SELECT customer_id,
       full_name,
       date_of_birth,
       gender,
       phone,
       address,
       note,
       EXTRACT(year FROM
               age(CURRENT_DATE::timestamp with time zone, date_of_birth::timestamp with time zone))::integer AS age
FROM customers c;

alter table vw_customers_with_age
    owner to postgres;

