create procedure sp_confirm_invoice_payment(IN p_invoice_id bigint)
    language plpgsql
as
$$
DECLARE
    v_warehouse_id BIGINT;
    v_status VARCHAR(30);
    v_item_count INT;
    v_total NUMERIC(15,2);
    v_cur_stock INT;
    r RECORD;
BEGIN
    SELECT warehouse_id, status, total_amount INTO v_warehouse_id, v_status, v_total
    FROM invoices
    WHERE invoice_id = p_invoice_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Không tìm thấy hóa đơn %.', p_invoice_id;
    END IF;

    IF v_status <> 'UNPAID' THEN
        RAISE EXCEPTION 'Hóa đơn không ở trạng thái chưa thanh toán (UNPAID).';
    END IF;

    SELECT COUNT(*) INTO v_item_count FROM invoice_items WHERE invoice_id = p_invoice_id;
    IF v_item_count = 0 THEN
        RAISE EXCEPTION 'Hóa đơn phải có ít nhất một dòng chi tiết.';
    END IF;

    -- Kiểm tra lại từng dòng và trừ tồn kho
    FOR r IN
        SELECT ii.batch_id, ii.quantity AS req_qty, b.exp_date
        FROM invoice_items ii
        JOIN batches b ON b.batch_id = ii.batch_id
        WHERE ii.invoice_id = p_invoice_id
    LOOP
        IF r.exp_date <= CURRENT_DATE THEN
            RAISE EXCEPTION 'Từ chối thanh toán: Lô thuốc % đã hết hạn sử dụng (%).', r.batch_id, r.exp_date;
        END IF;

        SELECT quantity INTO v_cur_stock
        FROM inventories
        WHERE warehouse_id = v_warehouse_id AND batch_id = r.batch_id
        FOR UPDATE;

        IF NOT FOUND OR v_cur_stock < r.req_qty THEN
            RAISE EXCEPTION 'Từ chối thanh toán: Lô thuốc % không đủ tồn kho (Tồn: %, Cần: %).', r.batch_id, COALESCE(v_cur_stock, 0), r.req_qty;
        END IF;

        UPDATE inventories
        SET quantity = quantity - r.req_qty,
            updated_at = CURRENT_TIMESTAMP
        WHERE warehouse_id = v_warehouse_id AND batch_id = r.batch_id;
    END LOOP;

    -- Cộng tiền vào tài khoản Chủ cửa hàng (Admin)
    UPDATE employees
    SET balance = balance + v_total
    WHERE position = 'ROLE_ADMIN' AND work_status = 'ACTIVE';

    -- Đổi trạng thái hóa đơn sang PAID
    UPDATE invoices
    SET status = 'PAID'
    WHERE invoice_id = p_invoice_id;
END;
$$;

alter procedure sp_confirm_invoice_payment(bigint) owner to postgres;

