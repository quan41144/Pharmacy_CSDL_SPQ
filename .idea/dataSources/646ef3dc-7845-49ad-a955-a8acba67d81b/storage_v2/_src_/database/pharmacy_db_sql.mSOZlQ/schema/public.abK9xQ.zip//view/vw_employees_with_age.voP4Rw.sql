create view vw_employees_with_age
            (employee_id, username, password, full_name, date_of_birth, gender, address, phone, start_date, position,
             work_status, balance, warehouse_id, age)
as
SELECT employee_id,
       username,
       password,
       full_name,
       date_of_birth,
       gender,
       address,
       phone,
       start_date,
       "position",
       work_status,
       balance,
       warehouse_id,
       EXTRACT(year FROM
               age(CURRENT_DATE::timestamp with time zone, date_of_birth::timestamp with time zone))::integer AS age
FROM employees e;

alter table vw_employees_with_age
    owner to postgres;

